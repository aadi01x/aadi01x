 <link rel="stylesheet" href="bootstrap/css/bootstrap.min.css" type="text/css" >
        <script type="text/javascript" src="bootstrap/js/jquery-3.3.1.min.js"></script>
        <script type="text/javascript" src="bootstrap/js/bootstrap.min.js"></script>
        <link href="css/style.css" rel="stylesheet" type="text/css"/> 
        <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.0/css/bootstrap.min.css">
<div style="position: relative;
  right: 0;
  bottom: 0;
  left: 0;
  padding: 1rem;
  color: white;
  background-color:black;
  text-align: center;">
        All Rights Preserved @ <strong>FANTASY CRICKET LEAGUE</strong><br/>
        <br/>
        
        </div>