# Fantasy_Cricket_League_Master
Script for Fantasy cricket league site using HTML,Bootstrap and PHP
# Admin functionality files
  1) Admin_Login.php
		> Simple PHP file which Authenticate ADMIN of System in order to perform Operation
		 by Admin.
     
  2) Admin_Portal.php
		> Simple PHP file where admin can see match name which is entered by him/her and also go for add new match. 
  
  3) Add_match.php
		> Simple PHP file where admin can add new match by entering team name and players of team.

  4) Add_Match_Confirm.php
		> Simple PHP file to add match information into database.

  5) delete_match.php
		>Simple PHP files which delete match when match is finished.

  6) Ad_match.php
		> Simple PHP file where match played and according to that player earns points.

  7) DevOps.php
		> PHP file which contain code to add points into different users account based on how players of that user perform in real match.
    
 # Site files 
 
   1) index.php
		> Display Home Page of Website.
    
   2) header.php
		> Contain code for header.
    
   3) footer.php
		> Contain code for footer.
    
   4) Login.php
		> Simple PHP file Where user enters Phone Number and Password to Login. 

   5) Reg.php
		> Simple PHP file for registration of any user.
    
   6) Logout.php
		> PHP file which perform action about logout user from system.
 
   7) Profile.php
		> PHP file which display profile page of user.
    
   8) Match.php
		>  PHP file where user select their team for particular match and if user has already select a team then display players of team.

   9) cap_vice_select.php
		>  PHP file where user  select a captain and vice-captain of his/her team. 
    
  10) display_team.php
		>  PHP file which display team of user.
		
  11) LIVE_MATCH.php
		>  PHP file where user can see leaderboard.

  12) Help.html
	 	> Instructions and policies of game.

  13) captcha.php
		> Captcha code for login authentication.	

  14) COUNTDOWN.php
	    > in Index show remaining time to start match.
